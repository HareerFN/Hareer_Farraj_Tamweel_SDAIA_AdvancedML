# بطاقة قرارك — Tamweel Lite

**الحالة:** جاهزة للمراجعة؛ لا تعني اعتمادًا أو درجة
**مصدر الأرقام:** LIVE · **الاستراتيجية:** weighted · **الصفوف:** 5,039 OOF

**المهمة:** الفئة الموجبة `default_within_90d=1` تعني حدث تعثر اصطناعي خلال90 يومًا بعد الطلب. كل طية تحقق طلبات لاحقة، وتستبعد عملاءها من التدريب وتشترط نضج نتيجة التدريب قبل بدايتها. المعرّفات والتاريخ خارج المدخلات.

| الدليل | القيمة |
|---|---:|
| العتبة المقيدة، بالقيمة الكاملة | 0.6583471436014694 |
| عتبة أقل خسارة دون قيد | 0.44863935722081005 |
| Recall | 40.89% |
| Precision | 29.85% |
| AP مجمع منOOF | 0.3100 |
| الإشارات | 526 من 5,039 |
| FN / FP | 227 / 369 |
| الخسارة التعليمية | 2639 وحدة |
| خسارة0.5 | 2403 وحدة؛ ضمن السعة: False |
| التغير عن0.5 | +236 وحدة؛ الموجب زيادة |
| خسارة لكل10,000 طلب، تطبيع حسابي | 5237.15 وحدة |
| فجوة معدل الإنذار الخاطئ بين المناطق | 0.648 نقطة مئوية |

**القاعدة:** درجة ≥ 0.6583471436014694 تعني إشارة مراجعة داخل التمرين؛ غير ذلك بلا إشارة. لا تتخذ موافقة أو رفض تمويل حقيقي. احفظ الدقة الكاملة؛ تقريب العتبة قد يغيّر حجم الطابور.

**السياسة:** FN=10 وFP=1 وحدات تعليمية، وسعة 12% لكل فترة بعد التقريب لأسفل. ليست ريالات فعلية أو رسوم أدوات أو خصمًا من الدرجة.

**دليل السعة:** الفترة 1: 137/195, الفترة 2: 183/200, الفترة 3: 206/207.

## لماذا اخترت هذه العتبة؟
I flag a request when the weighted model's score is >= 0.6583. This is the threshold with the lowest loss that still stays under the 12% review capacity in every period. It flags 526 of 5,039 requests (10.4%; 8.4%, 10.9% and 11.9% per period), with recall 40.9% and precision 29.9%. The default 0.5 flags 19.9% of requests, which breaks capacity, so it cannot be used. I declared the weighted strategy before comparing models, so the choice was not picked after seeing results.

## الخسارة والسعة
A missed default (FN) costs 10 units and a false alarm (FP) costs 1. Without a capacity limit, the lowest loss is at 0.4486 (2,275 units), but that flags 22.6% of requests, almost double the 12% team capacity. The capacity-feasible threshold 0.6583 costs 2,639 units: +364 vs the unconstrained minimum and +236 vs the default 0.5 (2,403). It also misses more defaults (227 FN vs 138). Capacity, not cost, is the binding constraint: with an FN cost of 8, 10 or 12 the threshold stays at 0.6583 and only the loss changes (2,185 / 2,639 / 3,093).

## فرق المناطق وما يحتاج إلى مراجعة
With one shared threshold, the false positive rate is similar across regions: 7.64% (other) to 8.29% (western), a gap of 0.65 percentage points. Recall differs more: 34.6% in western vs 48.2% in other, so defaults in western are caught less often. Each region has only about 81-104 defaults and no confidence intervals were computed, so these gaps are descriptive and may be noise. The data is also synthetic.

## حدود النتيجة
The threshold was chosen on the same OOF predictions used to judge it, so the result is optimistic and needs a separate final test. The weighted scores are not calibrated probabilities, so 0.6583 is a score rank, not a 65.8% default risk. Only 3 periods and 384 defaults were used. Period 3 used 206 of 207 slots, so a small shift could break capacity. The costs are educational units, not real SAR. FAST_MODE used 80 trees, 49.6% of rows (warm-up) have no OOF score, and fairness was checked only by region.

OOF تغطي 50.39% من التدريب و100% من الصفوف المؤهلة؛ 4,961 صفًا تمهيديًا بلا تنبؤ. اختيار العتبة وتقدير خسارتها هنا يستخدمان أهدافOOF نفسها؛ هذه نتيجة تطوير لا اختبار نهائي. لم نستخدم التحدي. المقارنة الجغرافية وصفية وليست شهادة عدالة، والأوزان لا تضمن معايرة الدرجات.

## سؤالك الأول: لماذا قد تخدعكAccuracy؟
Only 7.6% of requests default, so flagging nobody already gives 92.4% accuracy, with 0 recall and the highest loss (3,840 units). The unweighted model at 0.5 has the best accuracy (92.6%) but catches only 12.5% of defaults (loss 3,399). The weighted model has lower accuracy (81.3%) but recall 57.8% and lower loss (2,403). Accuracy treats a missed default and a false alarm as equal, but here a missed default costs 10 times more.

## سؤالك الثاني: لماذا تختار علىOOF؟
Each OOF prediction comes from a model that never saw that row: it was trained only on earlier, mature data with no shared customers. Choosing a threshold on in-sample scores would use overconfident predictions and give a threshold and loss that do not hold on new applicants. OOF scores act like future scoring, so the cost and capacity numbers are realistic. All 5,039 eligible rows have exactly one OOF score per strategy.

أدلتك في `artifacts/threshold_metrics.json` و`day3_period_capacity.csv` و`day3_region_audit.csv` و`day3_cost_sensitivity.csv` و`cost_curve.png`. الحساسية سيناريوهات ±20% لخسارةFN، وليست فترات ثقة. راجع السعة والمعايرة عند تغير البيانات؛ لا تفترض ثباتهما مستقبلًا.
