# تقريرك: التفسير والمعايرة — Tamweel Lite

**الحالة:** جاهز للمراجعة؛ لا يعني اعتمادًا أو درجة

**مصدر التفسير:** LIVE. **النموذج والمعايرة:** LIVE. **السعة:** CAPACITY_REVIEW_REQUIRED.

## النموذج والأدوار
LightGBM موزون، 80 شجرة. الهدف حدث تعثر اصطناعي خلال90 يومًا بعد الطلب. الأدوار منفصلة زمنيًا وبالعملاء: تدريب 2516، معايرة 584 (40 موجب)، سياسة 589، تقييم 1733. الفجوات والتداخلات مستبعدة. سبق استخدام بيانات التقييم في الدورة، فهي ليست اختبارًا نهائيًا لم يمسّ.

## التفسير العام والمحلي
Permutation يقيس انخفاضAP على التقييم؛ إشارات المنطقة تُبدّل معًا. SHAP يفسر النموذج الخام بوحدةlog-odds وخلفية مسارات أشجار التدريب. base+sum(SHAP)=raw margin، ثمsigmoid للمجموع فقط. القيم ليست نقاط احتمال ولا تفسيرًا مباشرًا للنموذج المعاير.

Global: on the sampled evaluation requests, mean |SHAP| ranks bureau_score first (0.904 log-odds), then dti (0.544) and loan_amount_sar (0.349). Permutation importance agrees on the top two: shuffling bureau_score drops AP by 0.127 and dti by 0.069. Local: I explained the highest-risk sampled request, TR-009585. Its top reasons were bureau_score = 497 (+2.27 log-odds), dti = 1.28 (+1.20) and loan_amount_sar = 93,437 (+0.20); none of them were imputed. The beeswarm explains the whole model, while the waterfall and reason codes explain one decision.

SHAP values are in raw log-odds of the uncalibrated LightGBM model, not probability points. Base value plus contributions equals the raw margin exactly (max additivity error 5.7e-15). For TR-009585 the raw score is 0.903, but the calibrated probability is 0.480, because the sigmoid calibrator is applied after the model, so SHAP does not directly explain the calibrated probability. Permutation importance is measured in AP drop, and training gain in split-gain units, so the three measures cannot be compared directly.

الطلب الاصطناعي TR-009585: الدرجة الخام 0.90308 والاحتمال المعاير 0.47952. اختير أعلى درجة داخل عينةSHAP دون استخدام النتيجة الفعلية.
- استخدم النموذج درجة ائتمانية اصطناعية عند الطلب بالقيمة 497 لرفع درجته الخام؛ لا يثبت ذلك السببية. (SHAP=+2.2693 log-odds؛ قيمة معوضة: False)
- استخدم النموذج نسبة الالتزام مع القسط المقترح إلى الدخل بالقيمة 1.2806 لرفع درجته الخام؛ لا يثبت ذلك السببية. (SHAP=+1.1981 log-odds؛ قيمة معوضة: False)
- استخدم النموذج مبلغ التمويل المطلوب بالقيمة 93437.3 لرفع درجته الخام؛ لا يثبت ذلك السببية. (SHAP=+0.2007 log-odds؛ قيمة معوضة: False)

Reason codes show what the model relied on, not what causes default. Correlated features share signal: months_employed has high training gain (2,482) but almost no held-out AP drop (0.0025). The local example is a single request, and its reasons describe the raw score, not the calibrated probability. The ±1 bureau_score check only shows stability for tiny changes: the prediction (0.903) and the top 3 reasons stayed the same. The data and Arabic reason texts are synthetic, so they are not ready for real customer notices.

## دليل المعايرة
على 1733 صفًا و139 موجب: Brier 0.113027 → 0.067112؛ ECE 0.146871 → 0.022486. عشر حاويات متساوية العرض مع أعدادها فيday4_reliability_bins.csv. AP 0.258677 → 0.258677؛ ROC-AUC 0.770804 → 0.770804. هذه نتائج هذه العينة وليست ضمانًا لتحسن مستقبلي.

The sigmoid was fitted on a separate calibration role (584 rows) and frozen before evaluation. On 1,733 evaluation requests (139 defaults), Brier fell from 0.1130 to 0.0671, ECE from 0.1469 to 0.0225 and log loss from 0.358 to 0.247. The customer-cluster bootstrap 95% interval for the Brier change is [-0.054, -0.037], fully below zero. ECE improved in both quarters (2024Q3: 0.134 to 0.032; 2024Q4: 0.159 to 0.024). ROC-AUC (0.771) and AP (0.259) did not change, because calibration rescales scores without changing their order.

## الاستقرار
200 تكرارbootstrap صالح بسحب العملاء؛ فترات مئينية95% مع تثبيت النموذج والمعاير. لا تشمل تعلم النموذج أو المعايرة أو الانجراف المستقبلي، ولا تصف احتمال فرد. انحرافAP بين ربعي التقييم وصفي فقط. اختبارbureau_score±1 نُفذ؛ راجع day4_local_stability.csv.

Ranking is uncertain: AP is 0.259, with a customer-cluster 95% interval of 0.197 to 0.338. Quarterly AP was similar (0.275 in 2024Q3 and 0.271 in 2024Q4), but each quarter has only 61-78 defaults. The calibration gain is stable: every part of the Brier-change interval is an improvement. Locally, changing bureau_score by ±1 kept the same probability and the same top 3 reasons. FAST_MODE used fewer trees and bootstrap repeats, so the intervals are approximate.

## العتبة ومنطقة المراجعة
العتبة الخام 0.5881953696965011 اختيرت علىpolicy بخسارة10×FN+FP وسقف12% ثم نُقلت إلى 0.17331013263107387. لم تعدل باستخدام التقييم. المنطقة[0.15331, 0.19331] تشخيصية بعرض±0.02 وليست فترة ثقة. الاتحاد يحسب الطلب مرة واحدة.
- 2024Q3: السقف 100، الإشارات 97، اتحاد المراجعة 109.
- 2024Q4: السقف 107، الإشارات 109، اتحاد المراجعة 122.

The threshold was chosen on the policy role (589 rows): raw 0.5882, equal to calibrated 0.1733. It flagged 68 requests against a capacity of 70 (loss 387 units). On evaluation, 2024Q3 stayed within capacity (97 flags vs 100), but 2024Q4 exceeded it (109 vs 107). Adding the ±0.02 near-threshold band raises candidates to 109 and 122, both over capacity. Status is CAPACITY_REVIEW_REQUIRED. I did not retune on evaluation; the next step is a priority rule (review the highest scores first) or more review staff, decided on new policy data.

عند تجاوز السعة، وثّق الحاجة إلى تصميم سياسة جديدة على بيانات تطوير وتقييمها بدليل جديد. لا ترفع السقف ولا تقص الحالات بعد رؤية النتيجة. التفسير ليس سببية أو شهادة عدالة، والخسارة وحدات تعليمية لا رسوم أو خصم درجات. لا يستخدم هذا التمرين لتمويل حقيقي.
