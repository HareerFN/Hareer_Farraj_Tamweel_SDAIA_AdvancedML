# Tamweel Lite | مشروعك النهائي

## الملخص التنفيذي
القرار: الإبقاء على نموذج الانحدار اللوجستي المفرد بدلاً من التجميع، لأنه حقق أعلى متوسط دقة (AP = 0.392) مقابل 0.389 لأفضل تجميع، دون فائدة مقاسة تبرر التعقيد. العتبة المختارة تحقق استدعاء 46.9% ودقة 34.3% مع البقاء ضمن سعة المراجعة 12% في كل فترة. في دفعة التحدي (2,500 طلب) تجاوز 330 طلبًا العتبة، فطُبق الحد الأعلى ورُفعت 300 إشارة فقط. فجوة الإيجابيات الكاذبة بين المناطق نحو 4 نقاط مئوية وتحتاج متابعة. المشروع تعليمي على بيانات اصطناعية، ولا يُستخدم لقرارات تمويل حقيقية.

## Executive summary
Decision: keep the single Logistic Regression rather than an ensemble. It had the best mean AP (0.392 vs 0.389 for the best ensemble), so the extra complexity brings no measured gain. The chosen threshold gives recall 46.9% and precision 34.3% while staying within the 12% review capacity in every period. In the 2,500-request challenge batch, 330 requests passed the threshold, so the cap was applied and 300 were flagged. The regional false-positive gap of about 4 points needs monitoring. This is an educational project on synthetic data and must not be used for real financing decisions.

Decision: KEEP SINGLE / Logistic. Full-batch flags: 300/2500.

اقرأ reports/MODEL_CARD.md والسياسة في artifacts/final_policy.json. الحزمة للتدريب؛ ليست نتيجة تقييم نهائية أو إثبات تسليم. ادمج أدلة أيامك السابقة واحفظ الدفتر المنفذ والعرض.
